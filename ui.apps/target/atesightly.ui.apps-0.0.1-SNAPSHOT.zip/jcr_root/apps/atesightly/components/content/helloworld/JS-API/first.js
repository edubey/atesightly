
"use strict";
use(function () {
    log.info("Called");
    var info = {};    
    info.title = currentPage.title;
    return info;
});
